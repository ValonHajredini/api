<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/passport' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Passport\\PassportServiceProvider',
    ),
  ),
  'cyvelnet/laravel5-fractal' => 
  array (
    'providers' => 
    array (
      0 => 'Cyvelnet\\Laravel5Fractal\\Laravel5FractalServiceProvider',
    ),
    'aliases' => 
    array (
      'Fractal' => 'Cyvelnet\\Laravel5Fractal\\Facades\\Fractal',
    ),
  ),
);